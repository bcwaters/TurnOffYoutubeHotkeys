# Remove Youtube Hotkeys
This is a simple extension that removes youtube hotkeys whenever on youtube.com

## Instructions
Install the extension from chrome store or this directory and now hotkeys are disabled by default

Click the icon to enable hotkeys again

## Contribute
I made this cause no else did yet and youtube doesnt give users the options to remove hotkeys.

I don't plan on maintaining this really unless it gets heavily used.

If you make a pull request that improves this I will merge it and and republish the extension in the store.


### features that this repo could probably use. 
- update url permission and url checker to check all youtube domains... not just .com
- a mozilla version 
- a safari version

